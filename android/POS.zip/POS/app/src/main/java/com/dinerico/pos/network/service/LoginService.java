package com.dinerico.pos.network.service;

/**
 * Created by josephleon on 10/2/14.
 */
public class LoginService {
}

package com.dinerico.pos.view;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.dinerico.pos.R;
import com.dinerico.pos.network.config.ActivityBase;

public class ShopActivity extends ActivityBase {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_shop);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.shop, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.action_settings:
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }
  }
}

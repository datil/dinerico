package com.dinerico.pos.viewmodel;

/**
 * Created by josephleon on 10/3/14.
 */
public class ShopViewModel {

  
}
